'use strict';
var mongoose = require('mongoose');


var onDbReady = function (err) {
    if(err) {
        logger.error(err);
        throw new Error(err);
    }

    var path = require('path');
    var koa = require('koa');
    var bodyParser = require('koa-body-parser');
    var koaLogger = require('koa-logger');
    var mount = require('koa-mount');
    var cors = require('koa-cors');

    var app = koa();
    app.use(cors());

    app.use(bodyParser());
    app.use(koaLogger());


    var vulnerabilityRouter = require('vulnerabilityRouter');
    app.use(mount('/api', vulnerabilityRouter.middleware()));

    var server = require('http').Server(app.callback());


    var port = 3000;

    server.listen(port);


    console.info('Server started in localhost:' + port);
};
var mongoUri = 'mongodb://192.168.99.100:32768/vuln_db';
mongoose.connect(mongoUri, onDbReady);
