var app = angular.module('abirtone', [])
app.constant('API_URL', 'http://localhost:3000/api');
app.factory('VulnService', ['$http', 'API_URL', function($http, API_URL){
    var resource = '/vulnerability';
    var list = function () {
        return $http.get(API_URL + resource);
    };

    var remove = function(id){
        return $http.delete(API_URL + resource + '/' + id);
    };

    var save = function(vuln){
        return $http.post(API_URL + resource, vuln);
    };

    return {
        list: list,
        save: save,
        remove: remove
    };
}])
app.controller('VulnCtrl', ['VulnService', function(VulnService){
    var ctrl = this;
    ctrl.levels = [{
        label: 'Info',
        value: 4
    },{
        label: 'Low',
        value: 3
    },{
        label: 'Medium',
        value: 2
    },{
        label: 'High',
        value: 1
    },{
        label: 'Critical',
        value: 0
    }];
    var refreshList = function(){
        VulnService.list().then(function(data){
            ctrl.vulnerabilities = data.data;
        });
    };
    refreshList();

    ctrl.deleteVuln = function(vuln){
        VulnService.remove(vuln._id).then(function(){
            alert('eliminado correctamente');
            refreshList();
        })
    };

    ctrl.saveVuln = function(){
        VulnService.save(ctrl.vuln).then(function(){
            ctrl.vuln = {};
            ctrl.form.$setPristine();
            refreshList();
            ctrl.create = false;
            alert('Vulnerability successfully created');
        }, function(err){
            alert('Error to save vulnerability');
        });
    };
}]);
